package com.intecap.ejercicio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         Button btn_click = findViewById(R.id.btn_click);
         btn_click.setOnClickListener(this);

        Button btn_click1 = findViewById(R.id.btn_click1);
        btn_click1.setOnClickListener(this);
    }

    @Override

    public void onClick(View v) {

        switch (v.getId()){
            case R.id.btn_click:
        Toast.makeText(this, "Hola", Toast.LENGTH_SHORT).show();
        break;
            case R.id.btn_click1:
        Toast.makeText(this, "cerrar", Toast.LENGTH_SHORT).show();
        break;
        }
    }
}
